#include <cassert>
#include <cctype>
#include <cstddef>
#include "Exceptions.h"
#include "Game.h"
#include "Piece.h"
#include "Queen.h" 


namespace Chess
{
	/////////////////////////////////////
	// DO NOT MODIFY THIS FUNCTION!!!! //
	/////////////////////////////////////
	Game::Game() : is_white_turn(true) {
		// Add the pawns
		for (int i = 0; i < 8; i++) {
			board.add_piece(Position('A' + i, '1' + 1), 'P');
			board.add_piece(Position('A' + i, '1' + 6), 'p');
		}

		// Add the rooks
		board.add_piece(Position( 'A'+0 , '1'+0 ) , 'R' );
		board.add_piece(Position( 'A'+7 , '1'+0 ) , 'R' );
		board.add_piece(Position( 'A'+0 , '1'+7 ) , 'r' );
		board.add_piece(Position( 'A'+7 , '1'+7 ) , 'r' );

		// Add the knights
		board.add_piece(Position( 'A'+1 , '1'+0 ) , 'N' );
		board.add_piece(Position( 'A'+6 , '1'+0 ) , 'N' );
		board.add_piece(Position( 'A'+1 , '1'+7 ) , 'n' );
		board.add_piece(Position( 'A'+6 , '1'+7 ) , 'n' );

		// Add the bishops
		board.add_piece(Position( 'A'+2 , '1'+0 ) , 'B' );
		board.add_piece(Position( 'A'+5 , '1'+0 ) , 'B' );
		board.add_piece(Position( 'A'+2 , '1'+7 ) , 'b' );
		board.add_piece(Position( 'A'+5 , '1'+7 ) , 'b' );

		// Add the kings and queens
		board.add_piece(Position( 'A'+3 , '1'+0 ) , 'Q' );
		board.add_piece(Position( 'A'+4 , '1'+0 ) , 'K' );
		board.add_piece(Position( 'A'+3 , '1'+7 ) , 'q' );
		board.add_piece(Position( 'A'+4 , '1'+7 ) , 'k' );
	}

	void Game::change_turn(){
		is_white_turn = !is_white_turn;
	}
	void Game::make_move(const Position& start, const Position& end) {
		//start valid_move
		valid_move(start, end, is_white_turn);
	   //end valid_move

	   //move the piece on the actual board
		delete board(end);
		board.erase_key(end);
		board.add_piece(end, board(start)->to_ascii());
		delete board(start);
		board.erase_key(start); //ERASE KEY USED HERE 
		//do i need this line or does it revert to null?
		
		//board.add_piece(start, '-');

		//checks for piece promotion
		if(this->board(end)->is_white() && this->board(end)->to_ascii()=='P' && end.second == '8'){
			delete board(end);
			board.add_piece(end, 'Q');
		}else if(!this->board(end)->is_white() && this->board(end)->to_ascii()=='p' && end.second=='1'){
			delete board(end);
			board.add_piece(end, 'q');
		}
	}

	bool Game::in_check(const bool& white) const {
		// go through each space on the board and check if there is a piece
			// if there is a piece, call helper function with current position, king's position, and piece type to see
			// if the capture move would be legal
				// if legal, then in_check is true
		//std::cout << "in_check" << std::endl;
		bool in_check1 = false;
		
		char k = 'k';
		if (white) {
			k = 'K';
		}
		
		int k_col = 0;
		int k_row = 0;

		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				//edited to check if there's a piece at that position (avoids seg fault)
				if (board(Position('A' + i, '1' + j)) && (board(Position('A' + i, '1' + j))->to_ascii() == k)){
					k_col = 'A' + i;
					k_row = '1' + j;
					break;
				}
			}
		}
//boolean for new valid_move
		bool exceptions = true;

		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				if (board(Position('A' + i, '1' + j))){
					try {
						valid_move(Position('A' + i, '1' + j), Position(k_col, k_row), !is_white_turn);
						}
					catch(Chess::Exception const& err) {
						exceptions = false;
						}
						if(exceptions){
							return true;
							//in_check = true;
						//break;
					}
				}
				exceptions = true;
			}
		}

		return in_check1;
	}

	Position Game::in_check_piece(const bool& white) const {
		// go through each space on the board and check if there is a piece
			// if there is a piece, call helper function with current position, king's position, and piece type to see
			// if the capture move would be legal
				// if legal, then in_check is true
		//std::cout << "in_check" << std::endl;
		
		char k = 'k';
		if (white) {
			k = 'K';
		}
		
		int k_col = 0;
		int k_row = 0;

		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				//edited to check if there's a piece at that position (avoids seg fault)
				if (board(Position('A' + i, '1' + j)) && board(Position('A' + i, '1' + j))->to_ascii() == k){
					k_col = 'A' + i;
					k_row = '1' + j;
					break;
				}
			}
		}
//boolean for new valid_move
		bool exceptions = true;

		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				if (board(Position('A' + i, '1' + j))){
					try {
						valid_move(Position('A' + i, '1' + j), Position(k_col, k_row), !is_white_turn);
						}
					catch(Chess::Exception const& err) {
						exceptions = false;
						}
						if(exceptions){
							return Position('A' + i, '1' + j);
							//in_check = true;
						//break;
					}
				}
				exceptions = true;
			}
		}

		return Position('0', '0');
	}

	void Game::valid_move(const Position& start, const Position& end, bool white) const {
	   if(!(start.first >='A' && start.first<='H' && start.second>='1' && start.second <= '8')){
		throw Exception("start position is not on board");
	   }
	   if(!(end.first >='A' && end.first<='H' && end.second>='1' && end.second <= '8')){
		throw Exception("end position is not on board");
	   }
	   if(!(this->board(start))){
		throw Exception("no piece at start position");
	   }
	   if(!((white && this->board(start)->is_white())||(!white && !this->board(start)->is_white()))){
		throw Exception("piece color and turn do not match");
	   }
	   if(!(this->board(end))|| this->board(end)== nullptr){
		if(!(this->board(start)->legal_move_shape(start, end))
		//should we check if start == end? is that illegal???
		||(start == end)){
			throw Exception("illegal move shape");
		}
	   }
	   //if(this->board(end)) or != nullptr??? remove if change causes error
	   else if(this->board(end) != nullptr){
		//legal_capture_shape returns returns legal_move shape unless pawn
		if((this->board(end)->is_white()&&this->board(start)->is_white())||(!this->board(end)->is_white()&&!this->board(start)->is_white())){
			//std::cout << this->board(start)->to_ascii() << this->board(end)->to_ascii() << std::endl;
		throw Exception("cannot capture own piece");
	   }
	   if(!(this->board(start)->legal_capture_shape(start, end))){
			throw Exception("illegal capture shape");
		}
	   }
	  // if((this->board(end)->is_white()&&this->board(start)->is_white())||(!this->board(end)->is_white()&&!this->board(start)->is_white())){
	//	throw Exception("cannot capture own piece");
	  // }
	   char p = this->board(start)->to_ascii();
	   //vertical moves
	   //I'm only going to check every space until the last space
	   if((start.first == end.first) && (p=='p' || p=='P' || p=='q' || p=='Q' || p=='q' || p=='r' || p=='R' || p=='m' || p=='M')){
		//checks the difference between the two positions: ASCII arithmatic
		//assumes that legal moves has already been called and works
		int t = end.second - start.second;
		//if positive number, move "up" on board
		if(t>0){
			for(int i=1; i<t; i++){
				if(board(Position(start.first, start.second+i))){
					throw Exception("path is not clear");
				}
			}
		}else if(t<0){//if negative number, moves "down" on board
			for(int i= -1; i>t; i--){
				if(board(Position(start.first, start.second+i))){
					throw Exception("path is not clear");
				}
			}
		}
	   }
	   //check for horizontal moves
	   else if((start.second == end.second)&&(p=='Q' || p=='q' || p=='r' || p=='R' || p=='m' || p=='M')){
		int t = end.first - start.first;
		if(t>0){
			for(int i=1; i<t; i++){
				if(board(Position(start.first+i, start.second))){
					throw Exception("path is not clear");
				}
			}
	    }else if(t<0){
			for(int i= -1; i>t; i--){
				if(board(Position(start.first+i, start.second))){
					throw Exception("path is not clear");
				}
			}
		}
		}
		//checks the diagonal for bishop, queen or mystery
	   else if(p=='B' || p=='b' || p=='m' || p=='M' || p=='Q' || p=='q'){
		int t = end.first - start.first;
		int n = end.second - start.second;

		if(t>0 && n>0){
			for(int i=1; i<t; i++){
				//add i to both of them
				if(board(Position(start.first+i, start.second+i))){
					throw Exception("path is not clear");
				}
			}
		} else if (t>0 && n<0) {
			for(int i=1; i<t; i++){
			//add i to both of them
				if(board(Position(start.first+i, start.second-i))){
					throw Exception("path is not clear");
				}
			}
		} else if (t<0 && n>0) {
			for(int i=1; i<n; i++){
			//add i to both of them
				if(board(Position(start.first-i, start.second+i))){
					throw Exception("path is not clear");
				}
			}
		} else if(t<0 && n<0){
			for(int i= -1; i>t; i--){
				if(board(Position(start.first+i, start.second+i))){
					throw Exception("path is not clear");
				}
			}
	   }
	}

	   //checks for in check by making a copy of the game and then playing it
	   Game* GameCopy = new Game(*this);
	   //GameCopy->board = board;
	   //GameCopy->is_white_turn = is_white_turn;
	   //std::cout<<"Board Copy:"<<std::endl;
	   //GameCopy->board.display();
	   //std::cout<<&GameCopy->board<<std::endl;
	   //std::cout<<&this->board<<std::endl;
		//might not have needed to add "this" so many times

		//if(GameCopy->board(end)){
		delete GameCopy->board(end);
		GameCopy->board.erase_key(end);//}
		
		GameCopy->board.add_piece(end, board(start)->to_ascii());
		delete GameCopy->board(start);
		GameCopy->board.erase_key(start);
		//GameCopy->board.display();
		//is null piece always this '-' piece?
		//GameCopy->board.add_piece(start, '-');
	   //if((GameCopy->is_white_turn && GameCopy->in_check(is_white_turn)) || (!(GameCopy->is_white_turn) && GameCopy->in_check(!is_white_turn))){
	if((GameCopy->in_check(white))){
			throw Exception("move exposes check");
	   }
	  // std::cout<<"Game Copy:"<<std::endl;
	   //GameCopy->board.display();
	   //is that lack of a delete going to cause memory leak???
	   delete GameCopy;

		// if knight or pawn, return true since they can skip over pieces

		// else, check which piece it is and see if there are other pieces in the path
	}
	
/*
	bool Game::valid_move(const bool& white, const Position& start, const Position& end, const Piece* piece) const {
		if(!(end.first >='A' && end.first<='H' && end.second>='1' && end.second <= '8')){
		throw Exception("end position is not on board");
		return false;
	   }
	   if(!(start.first >='A' && start.first<='H' && start.second>='1' && start.second <= '8')){
		throw Exception("start position is not on board");
		return false;
	   }
	   if(!(this->board(start))){
		throw Exception("no piece at start position");
		return false;
	   }
	   if(!((is_white_turn && this->board(start)->is_white())||(!is_white_turn && !this->board(start)->is_white()))){
		throw Exception("piece color and turn do not match");
		return false;
	   }
	   if(this->board(end)){
		//legal_capture_shape returns returns legal_move shape unless pawn
		if(!(this->board(start)->legal_capture_shape(start, end))){
			throw Exception("illegal capture shape");
			return false;
		}
	   }else if(!(this->board(end))){
		if(!(this->board(start)->legal_move_shape(start, end))
		//should we check if start == end? is that illegal???
		||(start == end)){
			throw Exception("illegal move shape");
			return false;
		}
	   }
	   if((this->board(end)->is_white()&&this->board(start)->is_white())||(!this->board(end)->is_white()&&!this->board(start)->is_white())){
		throw Exception("cannot capture own piece");
		return false;
	   }
	   char p = this->board(start)->to_ascii();
	   //vertical moves
	   //I'm only going to check every space until the last space
	   if((start.first == end.first) && (p=='p' || p=='P' || p=='q' || p=='Q' || p=='q' || p=='r' || p=='R' || p=='m' || p=='M')){
		//checks the difference between the two positions: ASCII arithmatic
		//assumes that legal moves has already been called and works
		int t = end.second - start.second;
		//if positive number, move "up" on board
		if(t>0){
			for(int i=1; i<t; i++){
				if(board(Position(start.first, start.second+i))){
					throw Exception("path is not clear");
					return false;
				}
			}
		}else if(t<0){//if negative number, moves "down" on board
			for(int i= -1; i>t; i--){
				if(board(Position(start.first, start.second+i))){
					throw Exception("path is not clear");
					return false;
				}
			}
		}
	   }
	   //check for horizontal moves
	   else if((start.second == end.second)&&(p=='Q' || p=='q' || p=='r' || p=='R' || p=='m' || p=='M')){
		int t = end.first - start.first;
		if(t>0){
			for(int i=1; i<t; i++){
				if(board(Position(start.first+i, start.second))){
					throw Exception("path is not clear");
					return false;
				}
			}
	    }else if(t<0){
			for(int i= -1; i>t; i--){
				if(board(Position(start.first+i, start.second))){
					throw Exception("path is not clear");
					return false;
				}
			}
		}
		}
		//checks the diagonal for bishop, queen or mystery
	   else if(p=='B' || p=='b' || p=='m' || p=='M' || p=='Q' || p=='q'){
		int t = end.first - start.first;
		if(t>0){
			for(int i=1; i<t; i++){
				//add i to both of them
				if(board(Position(start.first+i, start.second+i))){
					throw Exception("path is not clear");
					return false;
				}
			}
		}else if(t<0){
			for(int i= -1; i>t; i--){
				if(board(Position(start.first+i, start.second+i))){
					throw Exception("path is not clear");
					return false;
				}
			}
	   }
	   }

	   //checks for in check by making a copy of the game and then playing it
	   Game* GameCopy = new Game;
	   GameCopy->board = board;
	   GameCopy->is_white_turn = is_white_turn;
		//might not have needed to add "this" so many times
		delete GameCopy->board(end);
		GameCopy->board.add_piece(end, board(start)->to_ascii());
		delete GameCopy->board(start);
		//is null piece always this '-' piece?
		GameCopy->board.add_piece(start, '-');
	   if((GameCopy->is_white_turn && GameCopy->in_check(is_white_turn)) || (!GameCopy->is_white_turn && GameCopy->in_check(!is_white_turn))){
			throw Exception("move exposes check");
			return false;
		

	   }
	   delete GameCopy;

		// if knight or pawn, return true since they can skip over pieces

		// else, check which piece it is and see if there are other pieces in the path
	}*/

	bool Game::in_mate(const bool& white) const {
	//first see if it is in check
	//then see if the king has a valid move to each square around it and if it is moved to each square around it that it will still be in check
	//then see if there are any other pieces in their hand 
		//if any of those pieces have a legal move at any space around the king
			//make that move, and see if it is still in check, if so, move on to the next piece. 
	 // if after all this it is still in check, then it is in mate . 
		if(!in_check(white)){ 
			return false; 
		}
		Position checking_piece_position = in_check_piece(white);

		//if its not in check at this position, it can't be in mate
		
	  
	  //check is valid move for each space around the kings current spot, because that function checks if its in check at that position as well
	  //find position of the king and save it in a variable
	  //king in question is:
	  char king = 'k';
	  if(white){ king = 'K';}
	  
		//I DIDNT DELETE THIS COPY YET , is it necessary
		/*
	  	Game * Copy = new Game;
		Copy->board = board;
		Copy->is_white_turn = is_white_turn;
		*/
		//go through board and find the current position of the king, save it in the variable curr below
	
		Chess::Position curr;
		for(int c = 0; c < 8; c++){
			for(int r = 0; r < 8; r++){
				if((board(Position('A' + c, '1' + r))) && board(Position('A' + c, '1' + r))->to_ascii() == king){
					curr = Position('A' + c, '1' + r);
					break;
				}
			}
		}
		//test all moves around curr position for king to move
		Chess::Position next = curr;

		//new bool for the valid_move exceptions
		bool exceptions = true;
		//start with one space rightward
			next.first = curr.first + 1; 
			//if its a possible move without being in check, then its not in mate.
			try{valid_move(curr, next, white);}
			catch(Chess::Exception const&){exceptions = false;}
			if(exceptions){ return false; } 
			 exceptions = true;
		// one space rightward and upward (right-up diagonal)
			next.second = curr.second + 1; // one space rightward and upward (right-up diagonal)
			try{valid_move(curr, next, white);}
			catch(Chess::Exception const&){exceptions = false;}
			if(exceptions){ return false; } 
			 exceptions = true;
		//directly upward: 
			next.first = curr.first;
			next.second = curr.second + 1; 
			try{valid_move(curr, next, white);}
			catch(Chess::Exception const&){exceptions = false;}
			if(exceptions){ return false; } 
			 exceptions = true;
		//up-left diagonal:
			next.first = curr.first -1;
			try{valid_move(curr, next, white);}
			catch(Chess::Exception const&){exceptions = false;}
			if(exceptions){ return false; } 
			 exceptions = true;
		//directly left by one space:
			next.second = curr.second;// next.first is already curr -1;
			try{valid_move(curr, next, white);}
			catch(Chess::Exception const&){exceptions = false;}
			if(exceptions){ return false; } 
			 exceptions = true;
		//diagonal left-down:
			next.second = curr.second -1;
			try{valid_move(curr, next, white);}
			catch(Chess::Exception const&){exceptions = false;}
			if(exceptions){ return false; } 
			 exceptions = true;
		//directly downward one space
			next.first = curr.first; // its already down one space from before
			try{valid_move(curr, next, white);}
			catch(Chess::Exception const&){exceptions = false;}
			if(exceptions){ return false; }
			 exceptions = true;
		//diagonal right-down:
			next.first = curr.first + 1;
			try{valid_move(curr, next, white);}
			catch(Chess::Exception const&){exceptions = false;}
			if(exceptions){ return false; }
			 exceptions = true; 
	//reset the next variable, and use it for  moving of pieces other than king.
	next.first = curr.first;
	next.second = curr.second;
	//next check if any other pieces can save the king, if not then its in mate. 
	for(int i = 0; i < 8; i++){
		for(int j = 0; j < 8; j++){
			exceptions = true;
			//if the piece is the same color as the king in check 
			if(board(Position('A' + i, '1' + j))!= nullptr && white == isupper(board(Position('A' + i, '1' + j))->to_ascii())){
			//make a variable to see if the piece can legally move to any space around the king using 
			//need to do this if statement multiple times to check if it can move to any space around the king.
				next.first = curr.first + 1; //checking directly rightward first 
				
				try{valid_move(Position('A' + i, '1' + j), checking_piece_position, white);}
				catch(Chess::Exception const& err){
					exceptions = false;
				}
				if( exceptions ){
					/*
					Game * temp = new Game;
					temp->board = board;
					temp->is_white_turn = is_white_turn;
					*/
					Game * temp = new Game(*this);
					temp->make_move(Position('A' + i, '1' + j), checking_piece_position);
					//if another piece can move to the king, and then the king not be in check, then its not in mate
					if(!in_check(white)){
						return false;
					}
					delete temp;
				}
				
				exceptions = true;
				try{valid_move(Position('A' + i, '1' + j), next, white);}
				catch(Chess::Exception const&){exceptions = false;}
				if( exceptions ){
					/*
					Game * temp = new Game;
					temp->board = board;
					temp->is_white_turn = is_white_turn;
					*/
					Game * temp = new Game(*this);
					temp->make_move(Position('A' + i, '1' + j), next);
					//if another piece can move to the king, and then the king not be in check, then its not in mate
					if(!in_check(white)){
						return false;
					}
					delete temp;
				}
				exceptions = true;
				next.second = curr.second + 1; // checking up-right diagonal
				try{valid_move(Position('A' + i, '1' + j), next, white);}
				catch(Chess::Exception const&){exceptions = false;}
				if( exceptions ){
					/*
					Game * temp = new Game;
					temp->board = board;
					temp->is_white_turn = is_white_turn;
					*/
					Game * temp = new Game(*this);
					temp->make_move(Position('A' + i, '1' + j), next);
					//if another piece can move to the king, and then the king not be in check, then its not in mate
					if(!in_check(white)){
						return false;
					}
					delete temp;
				}
				exceptions = true;
				//need to do this for every space. 
				//checking directly upward:
				next.first = curr.first - 1; 
				try{valid_move(Position('A' + i, '1' + j), next, white);}
				catch(Chess::Exception const&){exceptions = false;}
				if(exceptions){
					/*
					Game * temp = new Game;
					temp->board = board;
					temp->is_white_turn = is_white_turn;
					*/
					Game * temp = new Game(*this);
					temp->make_move(Position('A' + i, '1' + j), next);
					//if another piece can move to the king, and then the king not be in check, then its not in mate
					if(!in_check(white)){
						return false;
					}
					delete temp;
				}
				exceptions = true;
				//checking up-left diagnoal
				next.first = curr.first - 1;
				try{valid_move(Position('A' + i, '1' + j), next, white);}
				catch(Chess::Exception const&){exceptions = false;}
				if(exceptions){
					/*
					Game * temp = new Game;
					temp->board = board;
					temp->is_white_turn = is_white_turn;
					*/
					Game * temp = new Game(*this);
					temp->make_move(Position('A' + i, '1' + j), next);
					//if another piece can move to the king, and then the king not be in check, then its not in mate
					if(!in_check(white)){
						return false;
					}
					delete temp;
				}
				exceptions = true;
				//checking directly left 
				next.second = curr.second;
				try{valid_move(Position('A' + i, '1' + j), next, white);}
				catch(Chess::Exception const&){exceptions = false;}
				if(exceptions){
					/*
					Game * temp = new Game;
					temp->board = board;
					temp->is_white_turn = is_white_turn;
					*/
					Game * temp = new Game(*this);
					temp->make_move(Position('A' + i, '1' + j), next);
					//if another piece can move to the king, and then the king not be in check, then its not in mate
					if(!in_check(white)){
						return false;
					}
					delete temp;
				}
				exceptions = true;
				//checking left-down diagonal
				next.second = curr.second -1;
				try{valid_move(Position('A' + i, '1' + j), next, white);}
				catch(Chess::Exception const&){exceptions = false;}
				if(exceptions){
					/*
					Game * temp = new Game;
					temp->board = board;
					temp->is_white_turn = is_white_turn;
					*/
					Game * temp = new Game(*this);
				
					temp->make_move(Position('A' + i, '1' + j), next);
					//if another piece can move to the king, and then the king not be in check, then its not in mate
					if(!in_check(white)){
						return false;
					}
					delete temp;
				}
				exceptions = true;
				//checking directly down
				next.first = curr.first;
				try{valid_move(Position('A' + i, '1' + j), next, white);}
				catch(Chess::Exception const&){exceptions = false;}
				if(exceptions){
					/*
					Game * temp = new Game;
					temp->board = board;
					temp->is_white_turn = is_white_turn;
					*/
					Game * temp = new Game(*this);
					temp->make_move(Position('A' + i, '1' + j), next);
					//if another piece can move to the king, and then the king not be in check, then its not in mate
					if(!in_check(white)){
						return false;
					}
					delete temp;
				}
				exceptions = true;
				//checking down-right diagonal 
				next.first = curr.first + 1;
				try{valid_move(Position('A' + i, '1' + j), next, white);}
				catch(Chess::Exception const&){exceptions = false;}
				if(exceptions){
					/*
					Game * temp = new Game;
					temp->board = board;
					temp->is_white_turn = is_white_turn;
					*/
					Game * temp = new Game(*this);
					temp->make_move(Position('A' + i, '1' + j), next);
					//if another piece can move to the king, and then the king not be in check, then its not in mate
					if(!in_check(white)){
						return false;
					}
					delete temp;
				}
			}
		}

	}
	return true;
	
	}

	/*bool Game::in_stalemate(const bool& white) const {
		//bool white means it's white's turn, checking if white is in stalemate
		//is brute force for stalemate also permitted?		
	   Game* GameCopy = new Game;
	   GameCopy->board = board;
	   GameCopy->is_white_turn = white;

	   //boolean for new valid_move function
	   bool exceptions = true;
		
		//iterates through every space on the board. if there's a piece there of the correct color,
		//it checks every space on the board to see if that end position is a legal move. If no legal moves,
		//in stalemate.
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				if(board(Position('A'+i, '1'+j))){
					char n = GameCopy->board(Position('A' + i, '1' + j))->to_ascii();
					std::cout<<n<<std::endl;
					if (white && (isupper(n))){
					for (int t = 0; t < 8; t++) {
						for (int n = 0; n < 8; n++) {
							try{valid_move(Position('A' + i, '1' + j), Position('A'+t, '1'+n), white);}
							catch(Chess::Exception const& e){
								std::cout<<e.what()<<std::endl;
								exceptions = false;}
							if(exceptions){
								delete GameCopy;
								std::cout<<"finished running stalemate"<<std::endl;
								return false;
							}
						}
					}
				}else if(!white && (islower(n))){
					for (int t = 0; t < 8; t++) {
						for (int n = 0; n < 8; n++) {
							try{valid_move(Position('A' + i, '1' + j), Position('A'+t, '1'+n), white);}
							catch(Chess::Exception const&){exceptions = false;}
							if(exceptions){
								delete GameCopy;
								std::cout<<"finished running stalemate"<<std::endl;
								return false;
							}
						}
					}
				}
				}
				
			//use isupper/islower instead of writing out if the piece equals each separate piece (K, B, Q, etc)
				
			}
		}

		delete GameCopy;

		std::cout<<"running stalemate"<<std::endl;
		return true;
	}*/

	bool Game::in_stalemate(const bool& white) const {
		//bool white means it's white's turn, checking if white is in stalemate

	   //boolean for new valid_move function
	   bool exceptions = true;
		
		//iterates through every space on the board. if there's a piece there of the correct color,
		//it checks every space on the board to see if that end position is a legal move. If no legal moves,
		//in stalemate.
		for(Board::const_iterator it = board.begin(); it != board.end(); ++it){
				if(board(*it) != nullptr){
					char n = board(*it)->to_ascii();
					if ((white && (isupper(n)))){
						
					for(Board::const_iterator nit = board.begin(); nit != board.end(); ++nit){
						exceptions = true;
							try{
								valid_move(*it, *nit, white);}
							catch(Chess::Exception const& e){
								exceptions = false;}
							if(exceptions){
								return false;
							}
						}
					}
				 else if(!white && (islower(n))){
					
					for(Board::const_iterator nit = board.begin(); nit != board.end(); ++nit){
						exceptions = true;
						//why does should this be white vs not white for valid move?
							try{valid_move(*it,*nit, white);}
							catch(Chess::Exception const&){exceptions = false;}
							if(exceptions){
								return false;
							}
						}
					}
				}
				}

		return true;
	}

    // Return the total material point value of the designated player
    int Game::point_value(const bool& white) const {
		
		int point_value = 0;
	
		for (int i = 'A'; i <= 'H'; i++) {
			for (int j = '0'; j <= '8'; j++) {
				//const Piece* piece1 = board(Position(i,j));
				if(board(Position(i,j))){
					const Piece* piece1 = board(Position(i,j));
					//should it be white or is_white_turn ??
					if(isupper(piece1->to_ascii())&& white){
						point_value += piece1->point_value();
					}
					if(islower(piece1->to_ascii())&& !white){
						point_value += piece1->point_value();
					}
				}

				}
			}

        return point_value;
    }

   std::istream& operator>> (std::istream& is, Game& game) {
       if (!is) {
           throw Exception("Cannot load the game!");
       }
 
       char piece;
       char col = 'A';
       char row = '8';
       int pos = 0;
 
       while (pos < 64 && is >> piece) {
           delete game.board(Position(col + (pos % 8), row - (pos/8)));
           game.board.erase_key(Position(col + (pos % 8), row - (pos/8)));
           if (piece != '-') {
               game.board.add_piece(Position(col + (pos % 8), row - (pos/8)), piece);
           }
           //std::cout << "after add_piece " << piece << std::endl;
           pos++;
       }
 
       if (pos != 64) {
           throw Exception("Cannot load the game!");
       }
 
       if (is >> piece) {
           if (piece == 'w') {
               game.is_white_turn = true;
           } else {
               game.is_white_turn = false;
           }
       } else {
           throw Exception("Cannot load the game!");
       }
      
       return is;
   }


    /////////////////////////////////////
    // DO NOT MODIFY THIS FUNCTION!!!! //
    /////////////////////////////////////
	std::ostream& operator<< (std::ostream& os, const Game& game) {
		// Write the board out and then either the character 'w' or the character 'b',
		// depending on whose turn it is
		return os << game.board << (game.turn_white() ? 'w' : 'b');
	}
}