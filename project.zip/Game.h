#ifndef GAME_H
#define GAME_H

#include <iostream>
#include "Piece.h"
#include "Board.h"
#include "Exceptions.h"

namespace Chess
{

	class Game {

	public:
		// This default constructor initializes a board with the standard
		// piece positions, and sets the state to white's turn
		Game();

		//Game(const Game& copy) : board(copy.board), is_white_turn(copy.is_white_turn){
		Game(const Game& copy) : is_white_turn(copy.is_white_turn){
			//std::cout<<"game copy constructor"<<std::endl;
			//Board * board1 = new Board(copy.board);
			//board = *(new Board(copy.board));
			//board  = *board1;

			//iterate through the board in THIS constructor if the board constructor isn't working

			for (int i = 0; i < 8; i++) {
				for (int j = 0; j < 8; j++) {
					//try{
						//Piece* piece = copy.occ.at(Position('A'+i, '1'+j));
						const Piece* piece = copy.board(Position('A'+i, '1'+j));
        				if(piece){
         				 //std::cout << piece->to_ascii() << "*";
							this->board.add_piece(Position('A'+i, '1'+j), piece->to_ascii());
        				}
        			//}
       				//catch(std::out_of_range const&){
	      				//std::cout << '-';  
					//}

			//this->board = copy.board;
			//std::cout<<"Game constructor board display"<<std::endl;
			//board.display();
			}
			}
		}

		Game& operator=(const Game& o){
			delete [] this;
			board = o.board;
			is_white_turn = o.is_white_turn;
			return *this;
		}
		

		~Game(){
			std::cout<<"game destructor called"<<std::endl;
			for(Board::const_iterator it = board.begin(); it != board.end(); ++it){
				if(board(*it) != nullptr){
					delete board(*it);
					board.erase_key(*it);
				}
			}
			//delete board;
		}

		// Returns true if it is white's turn
		/////////////////////////////////////
		// DO NOT MODIFY THIS FUNCTION!!!! //
		/////////////////////////////////////
		bool turn_white() const { return is_white_turn; }
		
    /////////////////////////////////////
		// DO NOT MODIFY THIS FUNCTION!!!! //
		/////////////////////////////////////
    // Displays the game by printing it to stdout
		void display() const { board.display(); }
    
    /////////////////////////////////////
		// DO NOT MODIFY THIS FUNCTION!!!! //
		/////////////////////////////////////
    // Checks if the game is valid
		bool is_valid_game() const { return board.has_valid_kings(); }

		// Attempts to make a move. If successful, the move is made and
		// the turn is switched white <-> black. Otherwise, an exception is thrown
		void make_move(const Position& start, const Position& end);

		// Returns true if the designated player is in check
		bool in_check(const bool& white) const;

		Position in_check_piece(const bool& white) const;

		void valid_move(const Position& start, const Position& end, bool white) const;

		// Returns true if the designated player is in mate
		bool in_mate(const bool& white) const;

		// Returns true if the designated player is in mate
		bool in_stalemate(const bool& white) const;

        // Return the total material point value of the designated player
        int point_value(const bool& white) const;

		void change_turn();
	private:
		// The board
		Board board;

		// Is it white's turn?
		bool is_white_turn;

        // Writes the board out to a stream
        friend std::ostream& operator<< (std::ostream& os, const Game& game);

        // Reads the board in from a stream
        friend std::istream& operator>> (std::istream& is, Game& game);
	};
}
#endif // GAME_H
