#ifndef BOARD_H
#define BOARD_H

#include <cstddef>
#include <iostream>
#include <map>
#include <stdexcept>
#include "Piece.h"
#include "Pawn.h"
#include "Rook.h"
#include "Knight.h"
#include "Bishop.h"
#include "Queen.h"
#include "King.h"
#include "Mystery.h"


namespace Chess
{
  class Board {

		// Throughout, we will be accessing board positions using Position defined in Piece.h.
		// The assumption is that the first value is the column with values in
		// {'A','B','C','D','E','F','G','H'} (all caps)
		// and the second is the row, with values in {'1','2','3','4','5','6','7','8'}

	public:
		// Default constructor
		Board();


		//copy constructor
		//Board(const Board &copy) : occ(copy.occ){
		Board(const Board &copy){
			std::cout<<"board constructor called"<<std::endl;
			/*copy.display();
			std::cout<<&copy<<std::endl;
			std::cout<<copy<<std::endl;
			this->display();
			std::cout<<this<<std::endl;
			std::cout<<*this<<std::endl;*/
			
		for (int i = 0; i < 8; i++) {
				for (int j = 0; j < 8; j++) {
					try{
						Piece* piece = copy.occ.at(Position('A'+i, '1'+j));
        				if(piece){
         				 //std::cout << piece->to_ascii() << "*";
							this->add_piece(Position('A'+i, '1'+j), piece->to_ascii());
        				}
        			}
       				catch(std::out_of_range const&){
	      				//std::cout << '-';  
					}
		}
		}
		std::cout<<"new board (this) after iterating:"<<std::endl;
		this->display();
		}
		

		Board& operator=(const Board& copy){
			//need to delete board?
			std::cout<<"seg 0"<<std::endl;
			delete this;
			std::cout<<"seg 0.1"<<std::endl;
			Board* newt = new Board(copy);
			//does that work correctly?
			std::cout<<"newt board"<<std::endl;
			newt->display();
			std::cout<<newt<<std::endl;
			std::cout<<"seg 0.5"<<std::endl;
			/*occ = copy.occ;
			for (int i = 0; i < 8; i++) {
				std::cout<<"seg 1"<<std::endl;
				for (int j = 0; i < 8; j++) {
					//char c = '\0';
					try{
						std::cout<<"seg 2"<<std::endl;
						Piece * next = copy.occ.at(Position('A'+i, '1'+j));
						std::cout<<"seg 3"<<std::endl;
						if(next){
							std::cout<<"seg 4"<<std::endl;
							this->add_piece(Position('A'+i, '1'+j), next->to_ascii());
							std::cout<<"seg 5"<<std::endl;
						}
					}catch(std::out_of_range const&){
						std::cout<<"seg 5"<<std::endl;
						//should I add a nullptr here?
					}
					
				}
			}*/
			
			return *newt;
		}

		virtual ~Board(){
			std::cout << "board destructor" << std::endl;
			//delete [] occ;
			/*
			for (int i = 0; i < 8; i++) {
				for (int j = 0; j < 8; j++) {
					try{
						Piece* piece = occ.at(Position('A'+i, '1'+j));
        				if(piece){
         				 //std::cout << piece->to_ascii() << "*";
							delete piece;
        				}
        			}
       				catch(std::out_of_range const&){
	      				//std::cout << '-';  
					}
				}
			}
			*/
		}

		// Returns a const pointer to the piece at a prescribed location if it exists,
		// or nullptr if there is nothing there.
		const Piece* operator() (const Position& position) const;

		// Attempts to add a new piece with the specified designator, at the given position.
		// Throw exception for the following cases:
		// -- the designator is invalid, throw exception with error message "invalid designator"
		// -- the specified position is not on the board, throw exception with error message "invalid position"
		// -- if the specified position is occupied, throw exception with error message "position is occupied"
		void add_piece(const Position& position, const char& piece_designator);

		// Displays the board by printing it to stdout
		void display() const;

		// Returns true if the board has the right number of kings on it
		bool has_valid_kings() const;

		void erase_key(const Position& pos); //Just added- function to erase key from map 
		/*
		class iterator {

			Position *it;

			
			Position *begin(Board& board) {
   				Position begin_pos = board.occ.begin()->first; 
    			return &begin_pos;
  			}

			Position *end(Board& board) {
				Position end_pos = board.occ.end()->first; 
				return &end_pos;
			}
			

			void operator++() {
				if (it->first > 'H') {
					++it->second;
					it->first = 'A';
				} else {
					++it->first;
				}
			}

		};
		*/

		
		/*class const_iterator {
			Position it;

			public:
			
			const_iterator(Position initial) : it(initial) { }

			const_iterator& operator++() {
				if (it.first == 'H') {
					++it.second;
					it.first = 'A';
					return *this;
				} else {
					++it.first;
					return *this;
				}

				
			}

				bool operator!=(const const_iterator& o) const { return it!=o.it; }

				Position operator*() { return it;}

				Position get(){return it;}

		};

		const_iterator begin(void)const {return const_iterator(Position('A','1'));}
		//would it return H8 OR H9 or I8?
		const_iterator end(void)const {return const_iterator(Position('A', '9'));};*/

		class const_iterator {
			Position it;

			public:
			
			const_iterator(Position initial) : it(initial) { }

			const_iterator& operator++() {
				if (it.first == 'H') {
					--it.second;
					it.first = 'A';
					return *this;
				} else {
					++it.first;
					return *this;
				}

				
			}

				bool operator!=(const const_iterator& o) const { return it!=o.it; }

				Position operator*() { return it;}

				Position get(){return it;}

		};

		const_iterator begin(void)const {return const_iterator(Position('A','8'));}
		//would it return H8 OR H9 or I8?
		const_iterator end(void)const {return const_iterator(Position('A', '0'));};
		

    
	private:
		// The sparse map storing the pieces, keyed off locations
		std::map<Position, Piece*> occ;

        // Write the board state to an output stream
        friend std::ostream& operator<< (std::ostream& os, const Board& board);
	};

}
#endif // BOARD_H